define(function(require) {
    var AppView = require('js/app');
    var appView = new AppView();
});
